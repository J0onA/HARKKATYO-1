Käytin harjoitustyössä pohjaa, jonka löysin internetistä, mutta jouduin sitä aika paljon muokkaamaan
json tiedostosta lukemisen takia. Lisäksi tein kuvanmuokkauksella oman hirsipuun etenemisen.

Jos index.html avaamisen yhteydessä saat "CORS" errorin. Lataa visual code ohjelmassa lisäosa, jolla voi
luoda HTTP palvelimen ja avaa nettisivu siinä.